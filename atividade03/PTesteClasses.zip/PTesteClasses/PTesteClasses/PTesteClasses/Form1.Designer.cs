﻿namespace PTesteClasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Horista = new System.Windows.Forms.Button();
            this.Mensalista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Horista
            // 
            this.Horista.Location = new System.Drawing.Point(256, 179);
            this.Horista.Name = "Horista";
            this.Horista.Size = new System.Drawing.Size(133, 63);
            this.Horista.TabIndex = 0;
            this.Horista.Text = "Horista";
            this.Horista.UseVisualStyleBackColor = true;
            this.Horista.Click += new System.EventHandler(this.Horista_Click);
            // 
            // Mensalista
            // 
            this.Mensalista.Location = new System.Drawing.Point(504, 179);
            this.Mensalista.Name = "Mensalista";
            this.Mensalista.Size = new System.Drawing.Size(142, 63);
            this.Mensalista.TabIndex = 1;
            this.Mensalista.Text = "Mensalista";
            this.Mensalista.UseVisualStyleBackColor = true;
            this.Mensalista.Click += new System.EventHandler(this.Mensalista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 445);
            this.Controls.Add(this.Mensalista);
            this.Controls.Add(this.Horista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Horista;
        private System.Windows.Forms.Button Mensalista;
    }
}

