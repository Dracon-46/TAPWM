﻿namespace PTesteClasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtData = new System.Windows.Forms.TextBox();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.BtnInstancia1 = new System.Windows.Forms.Button();
            this.LblDataEntrada = new System.Windows.Forms.Label();
            this.LblSalarioHora = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblMatricula = new System.Windows.Forms.Label();
            this.LblNumHora = new System.Windows.Forms.Label();
            this.TxtNumHora = new System.Windows.Forms.TextBox();
            this.LblFaltas = new System.Windows.Forms.Label();
            this.TxtFaltas = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtData
            // 
            this.TxtData.Location = new System.Drawing.Point(390, 220);
            this.TxtData.Name = "TxtData";
            this.TxtData.Size = new System.Drawing.Size(165, 26);
            this.TxtData.TabIndex = 19;
            // 
            // TxtSalario
            // 
            this.TxtSalario.Location = new System.Drawing.Point(337, 146);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(165, 26);
            this.TxtSalario.TabIndex = 18;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(337, 103);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(165, 26);
            this.TxtNome.TabIndex = 17;
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(337, 62);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(165, 26);
            this.TxtMatricula.TabIndex = 16;
            // 
            // BtnInstancia1
            // 
            this.BtnInstancia1.Location = new System.Drawing.Point(248, 311);
            this.BtnInstancia1.Name = "BtnInstancia1";
            this.BtnInstancia1.Size = new System.Drawing.Size(254, 90);
            this.BtnInstancia1.TabIndex = 14;
            this.BtnInstancia1.Text = "Instanciar Matricula";
            this.BtnInstancia1.UseVisualStyleBackColor = true;
            this.BtnInstancia1.Click += new System.EventHandler(this.BtnInstancia1_Click);
            // 
            // LblDataEntrada
            // 
            this.LblDataEntrada.AutoSize = true;
            this.LblDataEntrada.Location = new System.Drawing.Point(165, 223);
            this.LblDataEntrada.Name = "LblDataEntrada";
            this.LblDataEntrada.Size = new System.Drawing.Size(219, 20);
            this.LblDataEntrada.TabIndex = 13;
            this.LblDataEntrada.Text = "Data de Entrada Na Empresa";
            // 
            // LblSalarioHora
            // 
            this.LblSalarioHora.AutoSize = true;
            this.LblSalarioHora.Location = new System.Drawing.Point(165, 152);
            this.LblSalarioHora.Name = "LblSalarioHora";
            this.LblSalarioHora.Size = new System.Drawing.Size(124, 20);
            this.LblSalarioHora.TabIndex = 12;
            this.LblSalarioHora.Text = "Salario por Hora";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(165, 103);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(51, 20);
            this.LblNome.TabIndex = 11;
            this.LblNome.Text = "Nome";
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Location = new System.Drawing.Point(165, 68);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(73, 20);
            this.LblMatricula.TabIndex = 10;
            this.LblMatricula.Text = "Matricula";
            // 
            // LblNumHora
            // 
            this.LblNumHora.AutoSize = true;
            this.LblNumHora.Location = new System.Drawing.Point(165, 184);
            this.LblNumHora.Name = "LblNumHora";
            this.LblNumHora.Size = new System.Drawing.Size(134, 20);
            this.LblNumHora.TabIndex = 20;
            this.LblNumHora.Text = "Número de Horas";
            // 
            // TxtNumHora
            // 
            this.TxtNumHora.Location = new System.Drawing.Point(337, 184);
            this.TxtNumHora.Name = "TxtNumHora";
            this.TxtNumHora.Size = new System.Drawing.Size(165, 26);
            this.TxtNumHora.TabIndex = 21;
            // 
            // LblFaltas
            // 
            this.LblFaltas.AutoSize = true;
            this.LblFaltas.Location = new System.Drawing.Point(165, 256);
            this.LblFaltas.Name = "LblFaltas";
            this.LblFaltas.Size = new System.Drawing.Size(103, 20);
            this.LblFaltas.TabIndex = 22;
            this.LblFaltas.Text = "Dias de Falta";
            // 
            // TxtFaltas
            // 
            this.TxtFaltas.Location = new System.Drawing.Point(390, 250);
            this.TxtFaltas.Name = "TxtFaltas";
            this.TxtFaltas.Size = new System.Drawing.Size(165, 26);
            this.TxtFaltas.TabIndex = 23;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TxtFaltas);
            this.Controls.Add(this.LblFaltas);
            this.Controls.Add(this.TxtNumHora);
            this.Controls.Add(this.LblNumHora);
            this.Controls.Add(this.TxtData);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.BtnInstancia1);
            this.Controls.Add(this.LblDataEntrada);
            this.Controls.Add(this.LblSalarioHora);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblMatricula);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtData;
        private System.Windows.Forms.TextBox TxtSalario;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.Button BtnInstancia1;
        private System.Windows.Forms.Label LblDataEntrada;
        private System.Windows.Forms.Label LblSalarioHora;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.Label LblNumHora;
        private System.Windows.Forms.TextBox TxtNumHora;
        private System.Windows.Forms.Label LblFaltas;
        private System.Windows.Forms.TextBox TxtFaltas;
    }
}