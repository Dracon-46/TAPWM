﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void BtnInstancia1_Click(object sender, EventArgs e)
        {
            //Criando o objeto, instanciando o objeto
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = TxtNome.Text;
            objHorista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(TxtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(TxtNumHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(TxtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(TxtFaltas.Text);

            //mostrando valores
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" +"Matrícula: " + 
                objHorista.Matricula + "\n" + "Tempo de trabalho: " + 
                objHorista.TempoTrabalho() + "\n" + "Salário: " + 
                objHorista.SalarioBruto().ToString("N2"));
        }

     
    }
}
