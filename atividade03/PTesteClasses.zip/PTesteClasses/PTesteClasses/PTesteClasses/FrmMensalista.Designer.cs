﻿namespace PTesteClasses
{
    partial class FrmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMatricula = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalarioMensal = new System.Windows.Forms.Label();
            this.LblDataEntrada = new System.Windows.Forms.Label();
            this.BtnInstancia1 = new System.Windows.Forms.Button();
            this.BtnInstancia2 = new System.Windows.Forms.Button();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.TxtData = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Location = new System.Drawing.Point(136, 68);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(73, 20);
            this.LblMatricula.TabIndex = 0;
            this.LblMatricula.Text = "Matricula";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(136, 119);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(51, 20);
            this.LblNome.TabIndex = 1;
            this.LblNome.Text = "Nome";
            // 
            // LblSalarioMensal
            // 
            this.LblSalarioMensal.AutoSize = true;
            this.LblSalarioMensal.Location = new System.Drawing.Point(136, 175);
            this.LblSalarioMensal.Name = "LblSalarioMensal";
            this.LblSalarioMensal.Size = new System.Drawing.Size(113, 20);
            this.LblSalarioMensal.TabIndex = 2;
            this.LblSalarioMensal.Text = "Salario Mensal";
            // 
            // LblDataEntrada
            // 
            this.LblDataEntrada.AutoSize = true;
            this.LblDataEntrada.Location = new System.Drawing.Point(136, 223);
            this.LblDataEntrada.Name = "LblDataEntrada";
            this.LblDataEntrada.Size = new System.Drawing.Size(219, 20);
            this.LblDataEntrada.TabIndex = 3;
            this.LblDataEntrada.Text = "Data de Entrada Na Empresa";
            // 
            // BtnInstancia1
            // 
            this.BtnInstancia1.Location = new System.Drawing.Point(133, 316);
            this.BtnInstancia1.Name = "BtnInstancia1";
            this.BtnInstancia1.Size = new System.Drawing.Size(211, 72);
            this.BtnInstancia1.TabIndex = 4;
            this.BtnInstancia1.Text = "Instanciar Matricula";
            this.BtnInstancia1.UseVisualStyleBackColor = true;
            this.BtnInstancia1.Click += new System.EventHandler(this.BtnInstancia1_Click);
            // 
            // BtnInstancia2
            // 
            this.BtnInstancia2.Location = new System.Drawing.Point(399, 316);
            this.BtnInstancia2.Name = "BtnInstancia2";
            this.BtnInstancia2.Size = new System.Drawing.Size(211, 72);
            this.BtnInstancia2.TabIndex = 5;
            this.BtnInstancia2.Text = "Instanciar Mensalista Passando Parametros";
            this.BtnInstancia2.UseVisualStyleBackColor = true;
            this.BtnInstancia2.Click += new System.EventHandler(this.BtnInstancia2_Click);
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(308, 62);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(165, 26);
            this.TxtMatricula.TabIndex = 6;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(308, 113);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(165, 26);
            this.TxtNome.TabIndex = 7;
            // 
            // TxtSalario
            // 
            this.TxtSalario.Location = new System.Drawing.Point(308, 169);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(165, 26);
            this.TxtSalario.TabIndex = 8;
            // 
            // TxtData
            // 
            this.TxtData.Location = new System.Drawing.Point(361, 220);
            this.TxtData.Name = "TxtData";
            this.TxtData.Size = new System.Drawing.Size(165, 26);
            this.TxtData.TabIndex = 9;
            // 
            // FrmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TxtData);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.BtnInstancia2);
            this.Controls.Add(this.BtnInstancia1);
            this.Controls.Add(this.LblDataEntrada);
            this.Controls.Add(this.LblSalarioMensal);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblMatricula);
            this.Name = "FrmMensalista";
            this.Text = "FrmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalarioMensal;
        private System.Windows.Forms.Label LblDataEntrada;
        private System.Windows.Forms.Button BtnInstancia1;
        private System.Windows.Forms.Button BtnInstancia2;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtSalario;
        private System.Windows.Forms.TextBox TxtData;
    }
}