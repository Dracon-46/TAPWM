﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void BtnInstancia1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();
            objMensalista.NomeEmpregado = TxtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(TxtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(TxtSalario.Text);

            MessageBox.Show("Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Matricula = " + objMensalista.Matricula + "\n" +
                "Tempo Trabalho: " + objMensalista.TempoTrabalho() +
                "\n" + "Salario Final = " +
                objMensalista.SalarioBruto().ToString("N2")
                
                
                );

            MessageBox.Show("Empresa: " + Mensalista.empresa);

        }

        private void BtnInstancia2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                    Convert.ToInt32(TxtMatricula.Text),
                    TxtNome.Text, Convert.ToDateTime(TxtData.Text),
                    Convert.ToDouble(TxtSalario.Text)
                );

            MessageBox.Show("Nome: " + objMensalista.NomeEmpregado + "\n" +
               "Matricula = " + objMensalista.Matricula + "\n" +
               "Tempo Trabalho: " + objMensalista.TempoTrabalho() +
               "\n" + "Salario Final = " +
               objMensalista.SalarioBruto().ToString("N2")


               );
        }
    }
}
